# iot-device
This IoT device tracks a bus by sending geometries info
